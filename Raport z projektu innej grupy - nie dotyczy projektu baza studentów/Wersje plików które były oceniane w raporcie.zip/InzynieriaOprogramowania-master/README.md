Inzynieria Oprogramowania- projekt
========================

#Gra typu tower defence


#Wymagania

(1)- b. ważne
(2)- ważne
(3)- opcjonalne

##Funkcjonalne

1.	Menu (opisane szczegółowo w słowniczku).(1)*
2.	Prostota sterowania. (1)
3.	Stacjonarna walka z przeciwnikami, brak możliwości poruszania się. (1) *
4.	Wieża, którą broni gracz ma ograniczoną liczbę punktów życia. Gdy osiąga 0 gracz przegrywa (1) 
5.	Możliwość ulepszania broni. (2) *
6.	System gry umożliwiający zdobywanie XP w celu zdobywania nowych poziomów i broni. (2) *
7.	Możliwość ulepszenia wieży gracza. (3) *
8.	Płatności w grze za prawdziwe pieniądze. (3)

##Niefunkcjonalne
1.	Klimat gry w stylu Angry Birds, albo podobny.(1)
2.	Środowisko: Android.(1)
3.	Aplikacja skalowalna na jak największą ilość rozmiarów ekranów. (2)
4.	Autorskie grafiki. (2) *
5.	Wybór mapy. (3)
6.	Zmienna pogoda. (3)
7.	Wpływ pogody na rozgrywkę. (3)


***

##*Słowniczek

##Menu- zawiera opcje:
1.	Rozpoczęcie gry.
2.	Najlepsze wyniki.
3.	Pomoc (krótki opis gry, wytłumaczenie sterowania).
4.	Wyjście z gry.

###Możliwość ulepszania broni
gracz wraz z pokonaniem nowych poziomów uzyskuje możliwość odblokowania nowych broni, których może używać w następnych poziomach.

###XP
punkty doświadczenia. Gdy gracz zbierze określoną ilość punktów XP to jego poziom wzrasta o 1.

###Stacjonarna walka z przeciwnikami
gracz jest umiejscowiony w lewej części ekranu i nie ma możliwości poruszania się. Może jedynie zmieniać nachylenie broni oraz moc strzału.
Ulepszanie wieży gracza- zwiększanie liczby punktów życia.
Autorskie grafiki- grafiki mają być stworzone przez autorów aplikacji.

##Diagram USE-CASE
![alt tag](https://raw.githubusercontent.com/Pastew/InzynieriaOprogramowania/master/use%20case.jpg)
